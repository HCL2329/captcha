# SpringBoot2SimpleCaptchaApp
Spring Boot  Simple Captcha Application

## What is this?
SimpleCaptcha is a Java library for generating CAPTCHA challenge/answer pairs. 
SimpleCaptcha is intended to be easy to implement and use sensible defaults,
while providing easily-accesssible hooks for customization. 

## Source
http://simplecaptcha.sourceforge.net/
